#!/bin/bash
cd ~/
git clone git://source.ffmpeg.org/ffmpeg
cd ffmpeg
git checkout release/4.4
rm -r -f ".git"

ENABLED_DECODERS=(h264 hevc gif aac mp3 vorbis amrnb amrwb alac pcm_mulaw pcm_alaw)
HOST_PLATFORM="linux-x86_64"
NDK_PATH="/home/umerov/Android/Sdk/ndk/21.4.7075529"

echo 'Please input platform version (Example 21 - Android 5.0): '
read ANDROID_PLATFORM

cd /home/umerov/Fenrir-for-VK/libfenrir/src/main/jni/
./build_ffmpeg.sh "${NDK_PATH}" "${HOST_PLATFORM}" "${ANDROID_PLATFORM}" "${ENABLED_DECODERS[@]}"
