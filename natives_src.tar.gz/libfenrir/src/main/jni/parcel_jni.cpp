﻿#include <jni.h>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <list>
#include <utility>

using namespace std;

class Parcel {
public:
    static int8_t getBoolean(Parcel *&parcel) {
        if (parcel == nullptr) {
            return false;
        }

        ParcelEntity entity = parcel->read();
        int8_t ret = entity.readBool();

        if (parcel->parcels.empty()) {
            delete parcel;
            parcel = nullptr;
        }
        return ret;
    }

    static int8_t getByte(Parcel *&parcel) {
        if (parcel == nullptr) {
            return false;
        }

        ParcelEntity entity = parcel->read();
        int8_t ret = entity.readByte();

        if (parcel->parcels.empty()) {
            delete parcel;
            parcel = nullptr;
        }
        return ret;
    }

    static int32_t getInt(Parcel *&parcel) {
        if (parcel == nullptr) {
            return false;
        }

        ParcelEntity entity = parcel->read();
        int32_t ret = entity.readInt();

        if (parcel->parcels.empty()) {
            delete parcel;
            parcel = nullptr;
        }
        return ret;
    }

    static int64_t getLong(Parcel *&parcel) {
        if (parcel == nullptr) {
            return false;
        }

        ParcelEntity entity = parcel->read();
        int64_t ret = entity.readLong();

        if (parcel->parcels.empty()) {
            delete parcel;
            parcel = nullptr;
        }
        return ret;
    }

    static float getFloat(Parcel *&parcel) {
        if (parcel == nullptr) {
            return false;
        }

        ParcelEntity entity = parcel->read();
        float ret = entity.readFloat();

        if (parcel->parcels.empty()) {
            delete parcel;
            parcel = nullptr;
        }
        return ret;
    }

    static double getDouble(Parcel *&parcel) {
        if (parcel == nullptr) {
            return false;
        }

        ParcelEntity entity = parcel->read();
        double ret = entity.readDouble();

        if (parcel->parcels.empty()) {
            delete parcel;
            parcel = nullptr;
        }
        return ret;
    }

    static string getString(Parcel *&parcel) {
        if (parcel == nullptr) {
            return "";
        }

        ParcelEntity entity = parcel->read();
        string ret = entity.readString();

        if (parcel->parcels.empty()) {
            delete parcel;
            parcel = nullptr;
        }
        return ret;
    }

    static void putBoolean(Parcel *parcel, int8_t value) {
        if (parcel == nullptr) {
            return;
        }
        ParcelEntity entity;
        entity.putBoolean(value);
        parcel->parcels.push_back(entity);
    }

    static void putByte(Parcel *parcel, int8_t value) {
        if (parcel == nullptr) {
            return;
        }
        ParcelEntity entity;
        entity.putByte(value);
        parcel->parcels.push_back(entity);
    }

    static void putInt(Parcel *parcel, int32_t value) {
        if (parcel == nullptr) {
            return;
        }
        ParcelEntity entity;
        entity.putInt(value);
        parcel->parcels.push_back(entity);
    }

    static void putLong(Parcel *parcel, int64_t value) {
        if (parcel == nullptr) {
            return;
        }
        ParcelEntity entity;
        entity.putLong(value);
        parcel->parcels.push_back(entity);
    }

    static void putFloat(Parcel *parcel, float value) {
        if (parcel == nullptr) {
            return;
        }
        ParcelEntity entity;
        entity.putFloat(value);
        parcel->parcels.push_back(entity);
    }

    static void putDouble(Parcel *parcel, double value) {
        if (parcel == nullptr) {
            return;
        }
        ParcelEntity entity;
        entity.putDouble(value);
        parcel->parcels.push_back(entity);
    }

    static void putString(Parcel *parcel, string value) {
        if (parcel == nullptr) {
            return;
        }
        ParcelEntity entity;
        entity.putString(std::move(value));
        parcel->parcels.push_back(entity);
    }

private:
    class ParcelEntity {
    public:
        union DecNumber {
            int8_t byteValue;
            int32_t intValue;
            int64_t longValue{};
        };

        union FloatNumber {
            float floatValue;
            double doubleValue{};
        };

        ParcelEntity() {
            type = Types::TYPE_NULL;
        }

        void putBoolean(int8_t value) {
            type = Types::TYPE_BOOL;
            decNumber.byteValue = value;
        }

        void putByte(int8_t value) {
            type = Types::TYPE_BYTE;
            decNumber.byteValue = value;
        }

        void putInt(int32_t value) {
            type = Types::TYPE_INT;
            decNumber.intValue = value;
        }

        void putLong(int64_t value) {
            type = Types::TYPE_LONG;
            decNumber.longValue = value;
        }

        void putFloat(float value) {
            type = Types::TYPE_FLOAT;
            floatNumber.floatValue = value;
        }

        void putDouble(double value) {
            type = Types::TYPE_DOUBLE;
            floatNumber.doubleValue = value;
        }

        void putString(string value) {
            type = Types::TYPE_STRING;
            stringValue = std::move(value);
        }

        int8_t readBool() {
            if (type != Types::TYPE_BOOL) {
                return false;
            }
            return decNumber.byteValue;
        }

        int8_t readByte() {
            if (type != Types::TYPE_BYTE) {
                return 0;
            }
            return decNumber.byteValue;
        }

        int32_t readInt() {
            if (type != Types::TYPE_INT) {
                return 0;
            }
            return decNumber.intValue;
        }

        int64_t readLong() {
            if (type != Types::TYPE_LONG) {
                return 0;
            }
            return decNumber.longValue;
        }

        float readFloat() {
            if (type != Types::TYPE_FLOAT) {
                return 0;
            }
            return floatNumber.floatValue;
        }

        double readDouble() {
            if (type != Types::TYPE_DOUBLE) {
                return 0;
            }
            return floatNumber.doubleValue;
        }

        string readString() {
            if (type != Types::TYPE_STRING) {
                return "";
            }
            return stringValue;
        }

        enum class Types {
            TYPE_NULL,
            TYPE_BOOL,
            TYPE_BYTE,
            TYPE_INT,
            TYPE_LONG,
            TYPE_FLOAT,
            TYPE_DOUBLE,
            TYPE_STRING
        };
    private:
        Types type;
        DecNumber decNumber;
        FloatNumber floatNumber;
        string stringValue;
    };

    ParcelEntity read() {
        ParcelEntity entity = *parcels.begin();
        parcels.pop_front();
        return entity;
    }

    list<ParcelEntity> parcels;
};

extern "C" JNIEXPORT jlong
Java_dev_ragnarok_fenrir_module_parcel_ParcelNative_init(JNIEnv *, jclass) {
    auto *parcel = new Parcel();
    return (jlong) (intptr_t) parcel;
}

extern "C" JNIEXPORT void
Java_dev_ragnarok_fenrir_module_parcel_ParcelNative_putBoolean(JNIEnv *, jclass,
                                                               jlong parcel_native,
                                                               jboolean value) {
    if (!parcel_native) {
        return;
    }
    auto *parcel = (Parcel *) (intptr_t) parcel_native;
    Parcel::putBoolean(parcel, value);
}

extern "C" JNIEXPORT void
Java_dev_ragnarok_fenrir_module_parcel_ParcelNative_putByte(JNIEnv *, jclass, jlong parcel_native,
                                                            jbyte value) {
    if (!parcel_native) {
        return;
    }
    auto *parcel = (Parcel *) (intptr_t) parcel_native;
    Parcel::putByte(parcel, value);
}

extern "C" JNIEXPORT void
Java_dev_ragnarok_fenrir_module_parcel_ParcelNative_putInt(JNIEnv *, jclass, jlong parcel_native,
                                                           jint value) {
    if (!parcel_native) {
        return;
    }
    auto *parcel = (Parcel *) (intptr_t) parcel_native;
    Parcel::putInt(parcel, value);
}

extern "C" JNIEXPORT void
Java_dev_ragnarok_fenrir_module_parcel_ParcelNative_putLong(JNIEnv *, jclass, jlong parcel_native,
                                                            jlong value) {
    if (!parcel_native) {
        return;
    }
    auto *parcel = (Parcel *) (intptr_t) parcel_native;
    Parcel::putLong(parcel, value);
}

extern "C" JNIEXPORT void
Java_dev_ragnarok_fenrir_module_parcel_ParcelNative_putFloat(JNIEnv *, jclass, jlong parcel_native,
                                                             jfloat value) {
    if (!parcel_native) {
        return;
    }
    auto *parcel = (Parcel *) (intptr_t) parcel_native;
    Parcel::putFloat(parcel, value);
}

extern "C" JNIEXPORT void
Java_dev_ragnarok_fenrir_module_parcel_ParcelNative_putDouble(JNIEnv *, jclass, jlong parcel_native,
                                                              jdouble value) {
    if (!parcel_native) {
        return;
    }
    auto *parcel = (Parcel *) (intptr_t) parcel_native;
    Parcel::putDouble(parcel, value);
}

extern "C" JNIEXPORT void
Java_dev_ragnarok_fenrir_module_parcel_ParcelNative_putString(JNIEnv *env, jclass,
                                                              jlong parcel_native,
                                                              jstring value) {
    if (!parcel_native) {
        return;
    }
    auto *parcel = (Parcel *) (intptr_t) parcel_native;
    char const *textString = env->GetStringUTFChars(value, nullptr);
    Parcel::putString(parcel, textString);
    if (textString != nullptr) {
        env->ReleaseStringUTFChars(value, textString);
    }
}

extern "C" JNIEXPORT jboolean
Java_dev_ragnarok_fenrir_module_parcel_ParcelNative_readBoolean(JNIEnv *env, jclass,
                                                                jlong parcel_native,
                                                                jobject listener) {
    if (!parcel_native) {
        return 0;
    }
    auto *parcel = (Parcel *) (intptr_t) parcel_native;
    auto ret = Parcel::getBoolean(parcel);

    if (parcel == nullptr && listener != nullptr) {
        jweak store_Wlistener = env->NewWeakGlobalRef(listener);
        jclass ref = env->GetObjectClass(store_Wlistener);
        auto method = env->GetMethodID(ref, "doUpdateNative", "(J)V");
        if (ref != nullptr && method != nullptr) {
            env->CallVoidMethod(store_Wlistener, method, 0ll);
        }
    }

    return (uint8_t) ret;
}

extern "C" JNIEXPORT jbyte
Java_dev_ragnarok_fenrir_module_parcel_ParcelNative_readByte(JNIEnv *env, jclass,
                                                             jlong parcel_native,
                                                             jobject listener) {
    if (!parcel_native) {
        return 0;
    }
    auto *parcel = (Parcel *) (intptr_t) parcel_native;
    auto ret = Parcel::getByte(parcel);

    if (parcel == nullptr && listener != nullptr) {
        jweak store_Wlistener = env->NewWeakGlobalRef(listener);
        jclass ref = env->GetObjectClass(store_Wlistener);
        auto method = env->GetMethodID(ref, "doUpdateNative", "(J)V");
        if (ref != nullptr && method != nullptr) {
            env->CallVoidMethod(store_Wlistener, method, 0ll);
        }
    }

    return ret;
}

extern "C" JNIEXPORT jint
Java_dev_ragnarok_fenrir_module_parcel_ParcelNative_readInt(JNIEnv *env, jclass,
                                                            jlong parcel_native,
                                                            jobject listener) {
    if (!parcel_native) {
        return 0;
    }
    auto *parcel = (Parcel *) (intptr_t) parcel_native;
    auto ret = Parcel::getInt(parcel);

    if (parcel == nullptr && listener != nullptr) {
        jweak store_Wlistener = env->NewWeakGlobalRef(listener);
        jclass ref = env->GetObjectClass(store_Wlistener);
        auto method = env->GetMethodID(ref, "doUpdateNative", "(J)V");
        if (ref != nullptr && method != nullptr) {
            env->CallVoidMethod(store_Wlistener, method, 0ll);
        }
    }

    return ret;
}

extern "C" JNIEXPORT jlong
Java_dev_ragnarok_fenrir_module_parcel_ParcelNative_readLong(JNIEnv *env, jclass,
                                                             jlong parcel_native,
                                                             jobject listener) {
    if (!parcel_native) {
        return 0;
    }
    auto *parcel = (Parcel *) (intptr_t) parcel_native;
    auto ret = Parcel::getLong(parcel);

    if (parcel == nullptr && listener != nullptr) {
        jweak store_Wlistener = env->NewWeakGlobalRef(listener);
        jclass ref = env->GetObjectClass(store_Wlistener);
        auto method = env->GetMethodID(ref, "doUpdateNative", "(J)V");
        if (ref != nullptr && method != nullptr) {
            env->CallVoidMethod(store_Wlistener, method, 0ll);
        }
    }

    return ret;
}

extern "C" JNIEXPORT jfloat
Java_dev_ragnarok_fenrir_module_parcel_ParcelNative_readFloat(JNIEnv *env, jclass,
                                                              jlong parcel_native,
                                                              jobject listener) {
    if (!parcel_native) {
        return 0;
    }
    auto *parcel = (Parcel *) (intptr_t) parcel_native;
    auto ret = Parcel::getFloat(parcel);

    if (parcel == nullptr && listener != nullptr) {
        jweak store_Wlistener = env->NewWeakGlobalRef(listener);
        jclass ref = env->GetObjectClass(store_Wlistener);
        auto method = env->GetMethodID(ref, "doUpdateNative", "(J)V");
        if (ref != nullptr && method != nullptr) {
            env->CallVoidMethod(store_Wlistener, method, 0ll);
        }
    }

    return ret;
}

extern "C" JNIEXPORT jdouble
Java_dev_ragnarok_fenrir_module_parcel_ParcelNative_readDouble(JNIEnv *env, jclass,
                                                               jlong parcel_native,
                                                               jobject listener) {
    if (!parcel_native) {
        return 0;
    }
    auto *parcel = (Parcel *) (intptr_t) parcel_native;
    auto ret = Parcel::getDouble(parcel);


    if (parcel == nullptr && listener != nullptr) {
        jweak store_Wlistener = env->NewWeakGlobalRef(listener);
        jclass ref = env->GetObjectClass(store_Wlistener);
        auto method = env->GetMethodID(ref, "doUpdateNative", "(J)V");
        if (ref != nullptr && method != nullptr) {
            env->CallVoidMethod(store_Wlistener, method, 0ll);
        }
    }

    return ret;
}

extern "C" JNIEXPORT jstring
Java_dev_ragnarok_fenrir_module_parcel_ParcelNative_readString(JNIEnv *env, jclass,
                                                               jlong parcel_native,
                                                               jobject listener) {
    if (!parcel_native) {
        return env->NewStringUTF("error");
    }
    auto *parcel = (Parcel *) (intptr_t) parcel_native;
    auto ret = Parcel::getString(parcel);

    if (parcel == nullptr && listener != nullptr) {
        jweak store_Wlistener = env->NewWeakGlobalRef(listener);
        jclass ref = env->GetObjectClass(store_Wlistener);
        auto method = env->GetMethodID(ref, "doUpdateNative", "(J)V");
        if (ref != nullptr && method != nullptr) {
            env->CallVoidMethod(store_Wlistener, method, 0ll);
        }
    }

    return env->NewStringUTF(ret.c_str());
}